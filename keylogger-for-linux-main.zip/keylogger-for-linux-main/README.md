# keylogger for linux

A simple keylogger for Linux written in C.

#### File

```bash
cd keylog/ 
sudo ./keylog -f file-to-write-to.txt
```

This will log all keystrokes to the specified file while the program is running.


### Server


#### stdout

```bash
cd keylog/
./server
```

This will write all keystrokes received from the client to stdout.

#### File

```we have to open terminal 
cd keylog/
./server -f file-to-write-to.txt
```

This will write all keystrokes received from the client to the specified file.

*Output

Each key press will cause a string representing that key to be written to the
chosen location, followed by a newline. When the program quits, an extra newline will be added.

#### Example

Typing `SPY ON YOU` and then quitting the program with `Ctrl-C` will cause the chosen location to contain the following.

```
s
p
y
SPACE
O
N
SPACE
Y
O
U
LEFTCTRL
C
```

## Building

```bash
cd keylog/
make
```


